#!/usr/bin/env bash
# create-rc-secret.sh -- idempotent helper for Rocket.Chat DB & Admin creds
#
#   ./create-rc-secret.sh          # create in current kube-context
#   ./create-rc-secret.sh export   # print manifest for another cluster
set -euo pipefail
NS="rocketchat"
SECRET_NAME="rc-db-secret"
ROOT_PASS=${ROCKETCHAT_ROOT_PASSWORD:-$(openssl rand -base64 18)}
DB_PASS=${ROCKETCHAT_DB_PASSWORD:-$(openssl rand -base64 18)}
ADMIN_USER=${ROCKETCHAT_ADMIN_USER:-admin}
ADMIN_EMAIL=${ROCKETCHAT_ADMIN_EMAIL:-admin@example.com}

b64() { printf %s "$1" | base64 -w0; }

MANIFEST=$(cat <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: ${SECRET_NAME}
  namespace: ${NS}
type: Opaque
stringData:
  mongodb-password: ${DB_PASS}
  root-password: ${ROOT_PASS}
  rocketchat-admin-user: ${ADMIN_USER}
  rocketchat-admin-email: ${ADMIN_EMAIL}
EOF
)

if [[ "${1:-}" == "export" ]]; then
  echo "$MANIFEST"
  exit 0
fi

kubectl create namespace "${NS}" --dry-run=client -o yaml | kubectl apply -f -
echo "$MANIFEST" | kubectl apply -f -
echo "✅ Secret ${SECRET_NAME} created in namespace ${NS}"
