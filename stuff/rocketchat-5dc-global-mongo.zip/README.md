# Rocket.Chat in 5 Data‑Centers – Single Global MongoDB

This repository provides **end‑to‑end, GitOps‑ready manifests** to deploy a highly‑available Rocket.Chat service in **five Kubernetes clusters / data‑centers** that all share a single global MongoDB replica‑set.

*Primary goals*  
* 🔄 Seamless fail‑over: any two DCs can disappear without losing write capability.  
* 🌍 Global low‑latency access via GSLB (e.g., F5 GTM, Cloudflare, Route 53 latency policy).  
* 🗄️ Unified object store (MinIO) with cross‑region replication for file uploads.  
* 📈 Full observability (Prometheus + Grafana dashboards).  
* 📦 Argo CD App‑of‑Apps pattern for automated roll‑outs.

---
## Directory layout

```text
.
├── README.md
├── argo/                       # Argo CD Application manifests
│   ├── mongodb-app.yaml
│   ├── rocketchat-app.yaml
│   ├── minio-app.yaml
│   └── monitoring-app.yaml
├── dashboards/                 # Grafana dashboards as ConfigMaps
│   ├── rocketchat-dashboard.yaml
│   ├── mongodb-replicaset.yaml
│   └── minio-overview.yaml
├── minio/                      # S3‑compatible object storage
│   ├── minio-common-values.yaml
│   ├── minio-dc1.yaml
│   ├── minio-dc2.yaml
│   ├── minio-dc3.yaml
│   ├── minio-dc4.yaml
│   ├── minio-dc5.yaml
│   └── replication-policy.json
├── priorityclasses/
│   └── mongo-primary-preference.yaml
├── secrets/
│   ├── create-rc-secret.sh
│   └── rc-env-secret-example.yaml
└── values/
    ├── rc-common-values.yaml
    ├── rc-dc1.yaml
    ├── rc-dc2.yaml
    ├── rc-dc3.yaml
    ├── rc-dc4.yaml
    └── rc-dc5.yaml
```

---
## Quick Start

1. **Generate shared Rocket.Chat secret** (root, database & OAuth creds):

    ```bash
    ./secrets/create-rc-secret.sh
    # Export & apply to other clusters
    ./secrets/create-rc-secret.sh export | kubectl --context dc2 apply -f -
    ```

2. **Bootstrap Argo CD** in each cluster (outside the scope here).

3. **Push this repo** to your Git server (GitHub, GitLab, Gitea).

4. **Create Argo App‑of‑Apps** pointing to `argo/rocketchat-app.yaml` (repeat per DC).

   Argo will sync:
   * Rocket.Chat (with the DC‑specific overrides)
   * MinIO (and sets up replication)
   * Kube‑Prometheus‑Stack + Dashboards

5. **Configure your GSLB** to health‑probe `/api/info` on each site and weight or geo‑route.

---
## Components & Versions

| Component       | Chart                            | Version |
|-----------------|----------------------------------|---------|
| Rocket.Chat     | `oci://registry-1.docker.io/bitnamicharts/rocketchat` | 6.24.0 |
| MongoDB         | `oci://registry-1.docker.io/bitnamicharts/mongodb`    | 16.5.1 |
| MinIO           | `oci://registry-1.docker.io/bitnamicharts/minio`      | 13.7.2 |
| Redis           | enabled as sub‑chart (Bitnami)                         | 19.5.1 |
| Prometheus Stack| kube‑prometheus‑stack (Helm stable)                   | 58.7.2 |

---
### Generated

*2025-06-03T00:21:03.869834Z*
