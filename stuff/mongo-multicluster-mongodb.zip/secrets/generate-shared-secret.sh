#!/usr/bin/env bash
# generate-shared-secret.sh
#
# Usage:
#   ./generate-shared-secret.sh <cluster-alias>      # create + apply locally
#   ./generate-shared-secret.sh export               # print manifest only
#
set -euo pipefail
NS="mongodb"
SECRET_NAME="mongo-shared-auth"

function b64() { printf %s "$1" | base64 -w0; }

ROOT_PASS=${MONGODB_ROOT_PASSWORD:-$(openssl rand -base64 18)}
SVC_PASS=${MONGODB_PASSWORD:-$(openssl rand -base64 18)}
KEY=$(openssl rand -base64 756)

MANIFEST=$(cat <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: ${SECRET_NAME}
  namespace: ${NS}
type: Opaque
data:
  replicaSetKey: $(b64 "$KEY")
  mongodb-root-password: $(b64 "$ROOT_PASS")
  mongodb-password: $(b64 "$SVC_PASS")
EOF
)

if [[ "${1:-}" == "export" ]]; then
  echo "$MANIFEST"
  exit 0
fi

kubectl create namespace "${NS}" --dry-run=client -o yaml | kubectl apply -f -
echo "$MANIFEST" | kubectl apply -f -
echo "✅ Secret ${SECRET_NAME} created in namespace ${NS} (${1:-local})."
