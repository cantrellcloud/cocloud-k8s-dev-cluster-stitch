# MongoDB Multi‑Cluster Replica‑Set (Bitnami Helm Chart)

This repository contains everything you need to deploy a **three‑member MongoDB replica‑set stretched across three independent Kubernetes clusters / data‑centers** using the Bitnami `mongodb` Helm chart.

## Repo layout

```text
.
├── README.md
├── secrets
│   ├── generate-shared-secret.sh
│   └── mongo-shared-auth-secret.yaml  # optional manifest form
└── values
    ├── common-values.yaml
    ├── dc1.yaml
    ├── dc2.yaml
    └── dc3.yaml
```

## Quick Start

1. **Generate & apply the shared Secret (run *once*):**

   ```bash
   ./secrets/generate-shared-secret.sh dc1
   ```

   Then export it and apply to the other clusters:

   ```bash
   ./secrets/generate-shared-secret.sh export | kubectl --context {dc2-context} apply -f -
   ./secrets/generate-shared-secret.sh export | kubectl --context {dc3-context} apply -f -
   ```

2. **Install MongoDB in each cluster (one member per cluster):**

   ```bash
   # DC‑1
   helm install mongo bitnami/mongodb -n mongodb \
     -f values/common-values.yaml -f values/dc1.yaml

   # DC‑2
   helm install mongo bitnami/mongodb -n mongodb \
     -f values/common-values.yaml -f values/dc2.yaml

   # DC‑3
   helm install mongo bitnami/mongodb -n mongodb \
     -f values/common-values.yaml -f values/dc3.yaml
   ```

   The Bitnami chart’s auto‑discovery init will form the replica‑set automatically.

3. **Verify**

   ```bash
   kubectl exec -n mongodb mongo-0 -- mongosh -u root -p "$MONGODB_ROOT_PASSWORD" --eval 'rs.status()'
   ```

## Files

* `values/common-values.yaml` – settings shared by **all** sites.
* `values/dc*.yaml` – site‑specific overrides (LB IP, labels, etc.).
* `secrets/generate-shared-secret.sh` – idempotent helper to:
    * create the `mongo-shared-auth` Secret (root + svc user + keyFile)
    * print a manifest for export to other clusters.
* `secrets/mongo-shared-auth-secret.yaml` – static example if you prefer to apply directly (update base64 blobs).

---  
*Generated: 2025-06-03T00:03:40.480688Z*
